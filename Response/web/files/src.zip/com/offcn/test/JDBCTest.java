package com.offcn.test;

import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JDBCTest {

    /**
     * 1、用最原始的方式书写代码，获取Java的数据库连接
     * 就相当于是我们在黑窗口输入用户名、密码登录mysql服务，
     * 只有登录之后，也就是Java代码获取到连接之后，才能够继续
     * 后续的增删改查操作
     *
     * java.sql.Driver 数据库驱动接口，所有数据库厂商都必须对这个接口提供实现类
     * java.sql.Connection 表示数据库的连接，将来获取到连接之后，对数据库的所有操作，都是通过连接对象来完成的
     */
    @Test
    public void testGetConnection1() throws SQLException {
        //1.创建驱动对象
        Driver driver = new com.mysql.jdbc.Driver();

        //Connection connect(String url, Properties info) 试图创建一个到给定 URL 的数据库连接。
        //2.获取数据库连接
        String url = "jdbc:mysql://localhost:3306/test";

        Properties info = new Properties();
        info.setProperty("user", "root");
        info.setProperty("password", "123");

        Connection connection = driver.connect(url, info);

        System.out.println(connection);
        connection.close();
    }

    /**
     * 在编码时，第三方的代码不允许出现，主要是为了解耦合，
     * 因此通过反射的方式创建第三方类的对象
     *
     * @throws Exception
     */
    @Test
    public void testGetConnection2() throws Exception {
        //1.反射加载Driver类，创建该类对象
        Class<?> clazz = Class.forName("com.mysql.jdbc.Driver");
        Driver driver = (Driver) clazz.newInstance();

        //2.获取连接
        String url = "jdbc:mysql://localhost:3306/test";
        Properties info = new Properties();
        info.setProperty("user", "root");
        info.setProperty("password", "123");

        Connection connection = driver.connect(url, info);
        System.out.println("connection = " + connection);

        //3.关闭资源
        connection.close();
    }

    /**
     * java.sql.DriverManager JDBC的驱动管理类，我们有了数据库驱动之后，不应该自己
     * 操作，而是交给DriverManager进行操作
     */
    @Test
    public void testGetConnection3() throws Exception {
        //1.反射创建Driver驱动对象
        Class<?> clazz = Class.forName("com.mysql.jdbc.Driver");
        Driver driver = (Driver) clazz.newInstance();

        //2.将驱动交给DriverManger进行注册管理
        DriverManager.registerDriver(driver);

        //3.通过DriverManger获取数据库连接
        //static Connection getConnection(String url, String user, String password) 试图建立到给定数据库 URL 的连接。
        String url = "jdbc:mysql:///test";
        String user = "root";
        String password = "123";
        Connection connection = DriverManager.getConnection(url, user, password);

        System.out.println("connection = " + connection);

        //4.关闭资源
        connection.close();
    }

    /**
     * 官方操作：准备了静态代码块，当mysql提供的Driver类加载的时候，
     *          会自动执行静态代码块，静态代码块会完成Driver对象的创建，
     *          以及DriverManger驱动的注册，因此我们自己可以省略不写
     * public class Driver extends NonRegisteringDriver implements java.sql.Driver {
     *     public Driver() throws SQLException {
     *     }
     *
     *     static {
     *         try {
     *             DriverManager.registerDriver(new Driver());
     *         } catch (SQLException var1) {
     *             throw new RuntimeException("Can't register driver!");
     *         }
     *     }
     * }
     *
     */
    @Test
    public void testGetConnection4() throws Exception {
        //1.反射创建Driver驱动对象
        Class<?> clazz = Class.forName("com.mysql.jdbc.Driver");

        //2.通过DriverManger获取数据库连接
        //static Connection getConnection(String url, String user, String password) 试图建立到给定数据库 URL 的连接。
        String url = "jdbc:mysql:///test";
        String user = "root";
        String password = "123";
        Connection connection = DriverManager.getConnection(url, user, password);

        System.out.println("connection = " + connection);

        //4.关闭资源
        connection.close();
    }

    @Test
    public void testGetConnection5() throws Exception {
        //1.加载配置文件准备数据
        InputStream is = JDBCTest.class.getClassLoader().getResourceAsStream("jdbc.properties");

        Properties properties = new Properties();
        properties.load(is);

        String driverClass = properties.getProperty("driverClass");
        String url = properties.getProperty("url");
        String username = properties.getProperty("username");
        String password = properties.getProperty("password");

        //2.反射加载驱动
        Class<?> clazz = Class.forName(driverClass);

        //3.通过DriverManger获取数据库连接
        Connection connection = DriverManager.getConnection(url, username, password);

        System.out.println("connection = " + connection);

        //4.关闭资源
        connection.close();
    }
}
